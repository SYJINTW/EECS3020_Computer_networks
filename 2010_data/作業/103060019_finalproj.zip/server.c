#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <string.h>
#include <strings.h>
#include <arpa/inet.h>
#include <unistd.h>
typedef struct student{
    char student_id[255];
    char email[255];
}data;
int main(int argc,const char *argv[]){
    /*create the query table*/
    FILE *fp;
    int size=0;
    data table[100];
    fp = fopen("query.txt","r");
    while(fscanf(fp,"%s%s",table[size].student_id,table[size].email)!=EOF){
        size++;
    }
    int socketfd;
    /*create socket*/
    socketfd = socket (AF_INET, SOCK_STREAM, 0);
    /*set the socket*/
    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;
    bzero( (char*) &server_addr, sizeof(server_addr) );
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(1234);
  
    /*bind the socket*/
    if( bind( socketfd, (struct sockaddr*) &server_addr, sizeof(server_addr) ) <0){ 
        perror("ERROR on binding");
        exit(1);
    }
    /*listen and accept*/
    int addr_size;
    int streamfd,status;
    char buffer[256];
    int quit = 0;
    char response[256];
    int find;
    int i;
    struct hostent *host;
    while(1){
        /*listen*/
        listen(socketfd,10);
        addr_size = sizeof(client_addr);
        /*accept*/
        streamfd = accept( socketfd, (struct sockaddr*) &client_addr, &addr_size );
	      if(streamfd <0){
            perror("ERROR on accept");
            exit(1);
        }
        /*if connection is established then start communicating*/
        while(1){
            strcpy(buffer,"What's your requirement? 1.DNS 2.QUERY 3.QUIT : ");
            write(streamfd,buffer,strlen(buffer));
            bzero(buffer,256);
            bzero(response,256);
            status = read (streamfd,buffer,255);
            if(status <0){
                perror("ERROR reading from socket");
                exit(1);
            } 
            /*response*/    
            if(buffer[0]=='1'){
                strcpy(buffer,"Input URL address : ");
                write(streamfd,buffer,strlen(buffer));
                bzero(buffer,256);
                status = read (streamfd,buffer,255);
                host = gethostbyname(buffer); 
                if(host==NULL){
                    strcpy(response, "No such URL address");
                }else{
                    strcpy(response, inet_ntoa(*((struct in_addr*)host->h_addr)));
                }
                status = write (streamfd,response,255);
            }else if(buffer[0]=='2'){
                find=0;
                strcpy(buffer,"Input student ID : ");
                write(streamfd,buffer,strlen(buffer));
                bzero(buffer,256);
                status = read (streamfd,buffer,255);
                for(i=0;i<size;i++){
                    if(strcmp(buffer,table[i].student_id)==0){
                        strcpy(response,table[i].email);
                        find=1;
                    }
                }
                if(!find){
                    strcpy(response,"No such student ID");
                }
                status = write (streamfd,response,255);
            }else{
                break;
            }      
                
        }

        
    }
    return 0;
}
         
