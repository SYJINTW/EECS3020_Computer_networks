#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
int main(int argc,const char *argv[]) {
    int socketfd;
    struct sockaddr_in server_addr;
    /*setup the server address*/
    bzero( (char *) &server_addr,sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(1234);
    server_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    /*create a socket*/
    socketfd = socket(AF_INET, SOCK_STREAM, 0);
    if(socketfd < 0 ){
        perror("ERROR opening socket");
        exit(1);
    }
    /*connect to the server*/
    if( connect(socketfd,(struct sockaddr *)&server_addr,sizeof(server_addr)) < 0 ){
        perror("ERROR connecting");
        exit(1);
    }
    char buffer[256];
    int status;
    int stop=0;
    while(1){
 
        /*What's your requirement?*/
        bzero(buffer,256);
        read(socketfd, buffer, 255);
        printf("%s", buffer);
        /*send message to the server*/
        scanf("%s",buffer);/*1,2,3*/
        write(socketfd,buffer,strlen(buffer));
        if (buffer[0] == '1'){
            bzero(buffer,256);
            status = read(socketfd, buffer, 255);
            printf("%s",buffer);/*Input URL address :*/
            bzero(buffer,256);
            scanf("%s",buffer);/*www.google.com*/
            status = write(socketfd, buffer, strlen(buffer));
            /*get the domain name*/
            bzero(buffer,256);
            status = read(socketfd, buffer, 255);
            printf("address get from domain name : %s\n\n",buffer);/*216.58.200.36*/
        }else if (buffer[0] == '2'){
            bzero(buffer,256);
            status = read(socketfd, buffer, 255);
            printf("%s",buffer);/*Input student ID: */
            bzero(buffer,256);
            scanf("%s",buffer);/*5566*/
            status = write(socketfd, buffer, strlen(buffer));
            /*get the email*/
            bzero(buffer,256);
            status = read(socketfd, buffer, 255);
            printf("Email get from server : %s\n\n",buffer);/*gmail.com*/
        }else{
            break;
        }
    }
    close(socketfd);
    return 0;
}

        
