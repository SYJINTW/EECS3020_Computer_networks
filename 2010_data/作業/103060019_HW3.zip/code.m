load('network_A.mat')
X=zeros(2,100);
for i=1:100
    if(A(1,i)==1)
        X(1,i)=1;
        X(2,i)=1;
    end
end
for length=2:100   
    for j=1:100
        if(X(1,j)==length-1)
               for i=1:100
                   if(A(j,i)==1 && X(2,i)==0)
                       X(1,i)=length;
                       X(2,i)=j;
                   end
               end
        end
    end
end
tree=zeros(100,100);
for i=1:100
    tree(i,X(2,i))=1;
    tree(X(2,i),i)=1;
end


